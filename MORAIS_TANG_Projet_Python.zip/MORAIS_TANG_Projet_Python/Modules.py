# -*- coding: utf-8 -*-
"""
Fichier composé des classes : Author et Corpus
"""
import re
import pandas as pd
import nltk

from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords




#Création de la classe Author
class Author:
    def __init__(self, name):
        self.name = name
        self.ndoc = 0
        self.production = []

    def add(self, production):
        self.ndoc += 1
        self.production.append(production)
        
    def __str__(self):
        return f"Auteur : {self.name}\t# productions : {self.ndoc}"




#Création de la classe Corpus
class Corpus:
    
    
    def __init__(self, nom):
        self.nom = nom
        self.authors = {}
        self.id2aut = {}
        self.id2doc = {}
        self.ndoc = 0
        self.naut = 0
        self.full_text = ""  # variable qui va contenir l'intégralité des textes


    def add(self, doc, full_text):
        if doc.auteur not in self.id2aut:
            self.naut += 1
            self.authors[self.naut] = Author(doc.auteur)
            self.id2aut[doc.auteur] = self.naut
        self.authors[self.id2aut[doc.auteur]].add(doc.texte) # On ajoute le texte

        self.ndoc += 1
        self.id2doc[self.ndoc] = doc
        self.full_text = full_text


    # Représentation
    def show(self, n_docs=-1, tri="abc"):
        docs = list(self.id2doc.values())
        if tri == "abc":  # Tri alphabÃ©tique
            docs = list(sorted(docs, key=lambda x: x.titre.lower()))[:n_docs]
        elif tri == "123":  # Tri temporel
            docs = list(sorted(docs, key=lambda x: x.date))[:n_docs]

        print("\n".join(list(map(repr, docs))))


    def __repr__(self):
        docs = list(self.id2doc.values())
        docs = list(sorted(docs, key=lambda x: x.titre.lower()))
        return "\n".join(list(map(str, docs)))
    
    
    
    # Fonction qui retourne les passages contenant un mot-clé
    # Se base sur la variable full_text
    def search(self, keyword):
    # Si la chaîne de caractères full_text n'a pas encore été construite, on la construit
        docs = list(self.id2doc.values())    
        if not self.full_text:
            for document in docs:
                self.full_text += docs+' || '
                
        # Séparation des phrases avec ||
        phrases = re.split(r'\|\|', self.full_text)
        
        # Liste pour stocker passages qui contiennent le mot
        passages = []
        
        for phrase in phrases:
            # Si le mot est trouvé dans au moins une phrase :
            if re.search(r'\b' + keyword + r'\b', phrase):
                passages.append(phrase)
                
        # Sinon :
        if len(passages) == 0:
            return "Aucun résultat trouvé."
            
        return passages # Retourne une liste



    # Fonction qui retourne un tableau des correspondance d'un mot-clé
    # Se base sur la variable full_text
    def concorde(self,keyword,n):
    # Si la chaîne de caractères full_text n'a pas encore été construite, on la construit
        docs = list(self.id2doc.values())    
        if not self.full_text:
            for document in docs:
                self.full_text += docs+' || '
                
        # Séparation des phrases avec ||
        phrases = re.split(r'\|\|', self.full_text)
        
        # Liste pour stocker passages qui contiennent le mot
        passages = []        
        
        ## Vérification de l'existence du mot
        for phrase in phrases:
            # Si le mot est trouvé dans au moins une phrase :
            if re.search(r'\b' + keyword + r'\b', phrase):
                passages.append(phrase)
            # Sinon :
        if len(passages) == 0:
            return "Aucun résultat trouvé."
        
        ## Création de la table de concordance
        df_concorde = pd.DataFrame(columns=["contexte gauche", "motif trouvé", "contexte droit"])
        for i in passages:
            match = re.search(keyword, i)
            start = match.start()
            end = match.end()
            
            # Obtenez les n caractères précédents et suivants le mot-clé
            left_context = "..."+i[start-n:start]
            right_context = i[end:end+n]+"..."
            
            df_concorde.loc[len(df_concorde)] = [left_context, keyword, right_context]
        
        return df_concorde # Retourne un dataframe
    
    
    
    def stats(self, texte_complet, n):
        
        def nettoyer_texte(self, texte):
            
            # Mise en minuscules
            texte_min = texte.lower()
            
            # Remplacement des passages à la ligne
            texte_saut_ligne = texte_min.replace("\n", " ")
            
            # Remplacement des caractères non alpha-numérique par une chaine vide (sauf les espaces)
            texte_ponctuation = re.sub(r'[^\w\s]', ' ', texte_saut_ligne)
            texte_ponctuation = re.sub('_',' ',texte_ponctuation)
            
            # Remplacement des chiffres par une chaine vide
            texte_ponctuation = re.sub(r'\d', ' ', texte_ponctuation)
            
            # On supprime les mots inférieurs à 1 caractere et supérieurs à 20 caracteres
            words = word_tokenize(texte_ponctuation)
            words = [w for w in words if len(w) > 1 and len(w) < 20]
            
            # On supprime les mots "inutiles"
            stop_words = stopwords.words('english')
            words = [w for w in words if not w in stop_words]

            
            # On reforme les phrases
            words = list(words)
            texte_traite = ' '.join(word for word in words)
            
            return texte_traite
        
        # Construction du vocabulaire
        vocabulaire = set()
        # Création de la liste des textes non-traités
        liste_texte = texte_complet.split("||")
        # Création de la liste des textes traités
        liste_textes_traites = []
        
        # Alimenter le vocabulaire & la liste des textes traités
        for texte in liste_texte:
            
            texte_traite = nettoyer_texte(self,texte)
            liste_textes_traites.append(texte_traite)
            
            mots = texte_traite.split(' ')
            vocabulaire.update(mots)
            
        vocabulaire = list(vocabulaire)
        
        # Création du tableau de fréquences
        freq = pd.DataFrame(columns=["mot","occurence_mot","occurence_doc"])
        
        
        # Pour chaque mot dans la liste de mots
    
        
        for i in vocabulaire :
            occurence_mot = 0
            occurence_doc = 0

            for t in liste_textes_traites :
                liste_mots = t.split(' ')

                # Compter le nombre d'occurence de mot
                for m in liste_mots :
                    if m == i :
                        occurence_mot += 1
                
                if i in liste_mots :
                    occurence_doc +=1
                        
            freq.loc[len(freq)] = [i, occurence_mot, occurence_doc]
        freq = freq.sort_values(by=["occurence_mot"], ascending=False)

        
        # Affichage des statistiques
        print("Nombre de mots différents dans le corpus:", len(vocabulaire))
        print("Top ",n," des mots les plus fréquents:")
        print(freq[:n])
        
        return freq
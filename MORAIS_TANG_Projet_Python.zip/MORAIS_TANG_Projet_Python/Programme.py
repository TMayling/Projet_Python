#########################################################
# ------------------- PROJET PYTHON ------------------- #
#########################################################

# Par Nathalie TANG et Clara MORAIS
# 2022, Université Lumière Lyon II

lancement_programme = int(input("\n \n \n \n \n \n----- SOUHAITEZ-VOUS INTERROGER LES API ? ----- \n \n Choix 1: Oui\n \n Choix 2: Non (passer directement à l'étape de l'analyse textuelle)\n  \n \n----> Choix : "))

#########################################
######## CHARGEMENT DES LIBRARIES #######
#########################################

# Librairies externes
import os
import pandas as pd
import praw # API Reddit
import urllib, urllib.request # API Arxiv
import xmltodict
import datetime
import pickle # Sauvegarde des données
import math

# Nos propres librairies
import Document as dc
from Modules import Corpus
from Modules import Author

# Dossier courant
cwd = os.getcwd()

if(lancement_programme == 1):

#########################################
#### ACQUISITION DES DONNEES - API ######
#########################################

    ####### PARTIE 1 : Chargement des données
    
        # 1.1 ----- REDDIT ------ #
    
    # Identification
    reddit = praw.Reddit(client_id='c12ONnD4VOKTEkovDESUtQ', client_secret='5W3RCbqdNuiLSZShJ5WcEiKhmIMmiQ', user_agent='Application Dev_V2')
    
    # Requete
    limit = 100
    subr = reddit.subreddit('Python')
    hot_posts = subr.hot(limit=limit)
    
    
    docs = []
    docs_bruts = [] # Répondre au TD
    
    # Ajout du texte dans docs
    for post in hot_posts:
    
        if len(post.selftext) == 0:  # ne pas prendre les textes vides
            pass
        
        docs.append(post.selftext.replace("\n", " ")) # Remlacer les sauts de ligne
        docs_bruts.append(("Reddit", post))
    
    
        # 1.2 ----- ARXIV ----- #
    
    
    # Requete
    query = "python"
    url = 'http://export.arxiv.org/api/query?search_query=all:' + query + '&start=0&max_results=100'
    
    
    # Parser les résultats
    url_read = urllib.request.urlopen(url)
    # url_read est un "byte stream" qui a besoin d'être décodé
    data = xmltodict.parse(url_read.read().decode('utf-8'))
    
    
    # Ajout du texte dans docs
    for entry in data["feed"]["entry"]:
    
        docs.append(entry["summary"].replace("\n", "")) # Remplacer les sauts de ligne
        docs_bruts.append(("ArXiv", entry))
    
    
    ####### PARTIE 2 : Sauvegarde des données
    
        # 2.1 Sauvegarde des données dans un dataframe
        
    df = pd.DataFrame(columns = ['id','texte','source'])
    
    print(docs_bruts[118][0])
    print(docs[0])
    
    for i in range(len(docs)):
        df = df.append({'id': i, 'texte': docs[i], 'source' : docs_bruts[i][0]}, ignore_index = True)
        
        
        # 2.2 Exporter les données
    df.to_csv(cwd+'/df.csv', index=False)
        
    
    ####### PARTIE 3 : Premières manipulations des données
    
        # On remplace les valeurs NaN par des vides sur la colonne texte
        # Afin d'eviter des erreurs de type
    df['texte'] = df['texte'].fillna('')
    
        # 3.1 Afficher la taille du corpus
        
    print("La taille du corpus est de : ",len(df)," documents")
    
        # 3.2 Afficher le nombre de mots et de phrases pour chaque doc
        
    for i in range(len(df)):
       # nombre de phrases
        print("Nombre de phrases : " + str(len(df['texte'][i].split("."))))
        print("Nombre de mots : " + str(len(df['texte'][i].split(" "))))
        
    
    nb_mots = 0
    for i in range(len(df)):
        mots = len(df['texte'][i].split(" "))
        nb_mots += mots
        
    print("Nombre de mots dans le corpus : ",nb_mots)
        
    nb_phrases = 0
    for i in range(len(df)):
        phrases = len(df['texte'][i].split("."))
        nb_phrases += phrases
      
    print("Nombre de phrases dans le corpus : ",nb_phrases)
    
    
        # 3.3 Supprimer les textes trop courts
    
    for i in range(len(df)):
        mots = len(df['texte'][i].split(" "))
        if mots < 20:
            df = df.drop(labels=i,axis=0)
            
        # 3.4 Tous les textes dans une seule chaine de caractère
    texte_one_row = " || ".join(df['texte'])


#########################################
#### PREMIERE STRUCTURATION DU CODE #####
#########################################

    ####### PARTIE 1 : Classe Document
    
        # 1.3 Créer une collection avec toutes les infos des Documents
        
    collection = []
    df_complet = pd.DataFrame( columns=['auteur', 'date','texte','titre','type','url'])
    for nature, doc in docs_bruts:
        
        if nature == "ArXiv": 
            
            vtype = "ArXiv"
            titre = doc["title"].replace('\n', '')  # Enlever retours à la ligne
            try:
                authors = ", ".join([a["name"] for a in doc["author"]])  # Liste d'auteurs
            except:
                authors = doc["author"]["name"]  # Si l'auteur est seul, pas besoin de liste
            summary = doc["summary"].replace("\n", "")  # Enlever retours à la ligne
            date = datetime.datetime.strptime(doc["published"], "%Y-%m-%dT%H:%M:%SZ").strftime("%Y/%m/%d")  # Formatage de la date en avec librairie datetime
    
            doc_classe = dc.Document(titre, authors, date, doc["id"], summary,vtype)  # CrÃ©ation du Document
            collection.append(doc_classe)  # Ajout du Document Ã  la liste.
    
            df_complet.loc[len(df_complet)] = [authors, date, summary, titre, vtype, doc["id"]]
    
    
        elif nature == "Reddit":
            
            vtype = "Reddit"
            titre = doc.title.replace("\n", '')
            auteur = str(doc.author)
            date = datetime.datetime.fromtimestamp(doc.created).strftime("%Y/%m/%d")
            url = "https://www.reddit.com/"+doc.permalink
            texte = doc.selftext.replace("\n", "")
    
            doc_classe = dc.Document(titre, auteur, date, url, texte,vtype)
            collection.append(doc_classe)
            
            df_complet.loc[len(df_complet)] = [auteur, date, texte, titre, vtype, url]
    
    
        # On exporte les données en CSV pour éviter d'interroger les API
    df_complet.to_csv(cwd+'/df_complet.csv', index=False)
    
    
    # Index des documents
    id2doc = {}
    for i, doc in enumerate(collection):
        id2doc[i] = doc.titre
        
        
    ####### PARTIE 2 : Classe Auteur
    
    
        # 2.3 Créer un dictionnaire avec la liste des auteurs
    
    authors = {}
    id2aut = {}
    num_auteurs_vus = 0
    
    # Creation de la liste+index des Auteurs
    for doc in collection:
        if doc.auteur not in id2aut:
            
            num_auteurs_vus += 1
            authors[num_auteurs_vus] = Author(doc.auteur)
            id2aut[doc.auteur] = num_auteurs_vus
    
        authors[id2aut[doc.auteur]].add(doc.texte)
    
        # 2.4 Statistiques
        
    ####### PARTIE 3 : Création du corpus
    
    
    corpus = Corpus("Mon corpus")
    
    # Construction du corpus à partir des documents
    for doc in collection:
        corpus.add(doc,texte_one_row)
    
        # 3.3 Sauvegarde du corpus dans un fichier pickle
    
    # Ouverture d'un fichier, puis écriture avec pickle
    with open(cwd+"/corpus.pkl", "wb") as f:
        pickle.dump(corpus, f)


#########################################
######## CHARGEMENT DES DONNEES #########
#########################################

elif(lancement_programme == 2):
    
    # Liste des documents récupérés grâces aux API
    df_complet = pd.read_csv(cwd+'/df_complet.csv')
    
    # Df : ID, texte, source
    df = pd.read_csv(cwd+'/df.csv')
    
    # Corpus
    with open(cwd+"/corpus.pkl", "rb") as f:
        corpus = pickle.load(f)
    
#########################################
###### ANALYSE DU CONTENU TEXTUEL #######
#########################################

    ####### PARTIE 1 : Travail sur les expressions régulières
    
        # 1.1 Fonction Search - Affiche les textes où on trouve le mot "package"
    passages = Corpus.search(corpus,"package")
    
        # 1.2 Fonction Concorde
    df_concorde = Corpus.concorde(corpus,"package",15)
    df_concorde.head()
    
    ####### PARTIE 2 : Quelques statistiques
    
    df_freq = Corpus.stats(corpus,corpus.full_text, 10)
    df_freq.head()


#########################################
########## MOTEUR DE RECHERCHE ##########
#########################################

####### PARTIE 1 : Matrice Documents x Mots

    # 1.1 Création d'un dictionnaire 

    vocab = {}
    
    # On itère sur le dataframe contenant les informations des mots
    for index, row in df_freq.iterrows(): # Fonction iterrows de pandas, permet de boucler sur un dataframe, retournant un tuple avec l'index et la valeur de la ligne
        mot = row['mot']
        occurence_mot = row['occurence_mot']
        occurence_doc = row['occurence_doc']
        # Création du dictionnaire contenant les informations du mot
        mot_info = {"id": index, "occurence": occurence_mot, "occurence_doc": occurence_doc}
        vocab[mot] = mot_info
    
    # 1.4 Alternative Matrice TFIDF
    
    tf_idf_scores = {} # Dictionnaire qui va contenir nos scores pour chaque mot
    N = corpus.ndoc # Nombre total de documents
    
    for word in vocab.keys():
        idf = math.log(N / vocab[word]["occurence_doc"])

        # calculate the term frequency (TF)
        tf = vocab[word]["occurence"] / len(vocab.keys())

        # calculate the TF-IDF score
        tf_idf_scores[word] = tf * idf